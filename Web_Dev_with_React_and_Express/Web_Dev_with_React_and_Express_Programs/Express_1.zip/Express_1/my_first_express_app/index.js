const express = require('express');
const app = express();
const info = require("./src/person")

app.use(express.static('public')); // accessing the the files inside the folder public
// editing the localhost's index page
app.get('/', (req, res) => {
     res.send("Welcome " + info.name); // the text that gets written to the index page
 })
// route handler that displays a message when an unrecognized directory
app.get("*", (req, res, next) => {
	let err = new Error("Page Not Found");
	err.statusCode = 404;
	next(err);
})

app.listen(3000) // listen method that specifies the port