const manipulated = require("./stringManip.js"); // fetching the js file with the code to write to the content.txt
//  running the js file that was fetched
console.log(manipulated);