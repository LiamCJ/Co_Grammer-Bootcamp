const primeGen = max => {
     const numbers = new Array(max).fill(true); // array filled with "true" the length of the parameter (max)
     /*  a for loop that loops the conditional that determines what numbers are not prime numbers for the square root of the parameter max 
     where the variable (i) is the index of each item in the array */
     for (let i = 2; i < Math.sqrt(max); i++) {
         /*If the value of the index determined by numbers[i] is true it's index will be squared and that number will be 
         made false in the array (numbers) since it is not a prime number*/
         if (numbers[i]) {
             for (let j = Math.pow(i, 2); j < max; j += i) {
                 numbers[j] = false
             }
         }
     }

     /* adding the prime numbers to the array (primes) by using the reduce function where primes is the total of the array, 
     isPrime is a current value of the array and i its index in the array */
     return numbers.reduce((primes, isPrime, i) => {
         // if the current value is true and it's index is more than 1 it is considered a prime number
         if (isPrime && i > 1) {
             primes.push(i)
         }

         return primes
     }, [])
 }
 console.log(primeGen(100))
module.exports = primeGen;