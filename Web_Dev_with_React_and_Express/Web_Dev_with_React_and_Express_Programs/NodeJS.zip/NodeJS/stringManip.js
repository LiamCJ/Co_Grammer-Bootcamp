const fileH = require('fs'); // variable that contains the file system module

var string , strTrim , strLower;
string = "		HELLO WORLD		"
strTrim = string.trim(); // removing white spaces from the beginning and ending of the text
strLower = strTrim.toLowerCase(); // making the text lower case


fileH.writeFile('content.txt', strLower, (err) => {
	// if any errors occur they will be displayed
    if (err) throw err;
    // console log to comfirm that the code worked
    console.log("Completed")
});

