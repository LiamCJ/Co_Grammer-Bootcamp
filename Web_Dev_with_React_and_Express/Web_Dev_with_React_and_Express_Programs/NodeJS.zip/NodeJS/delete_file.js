const fs = require('fs'); // variable that contains the file system module

fs.unlink("nums.txt",(err) => {
	if (err){
		console.log('File Not Deleted')
	}else {
		console.log('File Deleted')
	}

})