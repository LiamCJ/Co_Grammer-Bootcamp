const http = require("http"); // variable that stores the http protocol

http.createServer( (request, response) => { // creating the server 
	response.write("Hey! I Can Use Node.js"); // writing information the servers web page
	response.end(); // ending the response
}).listen(3000); // assigning the port