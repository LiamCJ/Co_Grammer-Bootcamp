const http = require("http");
const fs = require('fs'); // variable that contains the file system module
const primes = require("./primes.js");
const even = require("./even_nums.js");

fs.writeFile('nums.txt', "Prime Numbers :  \n" + primes(100), (err) => { // writing the outcome of the module primes
    // if any errors occur they will be displayed
    if (err) {
        console.log("Data was not written") // error message 
    } else {
        fs.appendFile('nums.txt', "\nEven Numbers :  \n" + even(50), () => { // appending the outcome of the module even_nums
            // console log to comfirm that the code worked
            console.log("Completed")
        })
    }
});


http.createServer((request, response) => { //  creating the server
    fs.readFile('nums.txt', (err, data) => { // reading the txt file "num.txt"
        if (err) {
            console.log("Data was not retrieved") // error message
        }else{
	         response.write(data); //write the data in the text file as a HTTP response
	         response.end();
       	}
    })
}).listen(8000);