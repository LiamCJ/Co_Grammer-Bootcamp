const even = (num) =>{
	var evens = [];
	// loops until the variable (n) reaches 49
	for (let n = 1; n < num; n++){
		// conditional statement that checks if (n) is divisible by 2  and returns a remainder of 0 if so it is a even a number and will be displayed
		if (n % 2 === 0){
			evens.push(n);
		}
	}
	return evens
}

module.exports = even;