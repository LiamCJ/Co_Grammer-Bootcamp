import React from "react";
import Dollars from "./dollars.js";
import Currency from "./currency.js";

//converts dollars to Rands
const toRands = dollars => {
    return dollars * 14.83;
};
//converts dollars to Euros
const toEuros = dollars => {
    return dollars * 0.9;
};
//converts dollars to Pounds
const toPounds = dollars => {
    return dollars * 0.82;
};
// function that parses the number entered by the user to a string 
const convert = (dollars, convert) => {
    const input = parseFloat(dollars);
    // if the input is blank the outputs of the currency change is also displayed blank
    if (Number.isNaN(input)) {
        return "";
    }
    // rounding off the users input to 1000 
    const rounded = Math.round(convert(input) * 1000) / 1000;
    return rounded.toString();
};

class Converter extends React.Component {
    constructor(props) {
        super(props);
        this.state = { dollars: "" };
    }

    currencyChange = dollars => {
        this.setState({ dollars });
    };

    render() {
        const dollars = this.state.dollars;
        return (
            <div>
        <Dollars dollars={dollars} onCurrencyChange={this.currencyChange} />
        <Currency
        value="Rands:"
          dollars={convert(dollars, toRands)}
        />
        <Currency
        value="Euros:"
          dollars={convert(dollars, toEuros)}
        />
        <Currency
        value="Pounds:"
          dollars={convert(dollars, toPounds)}
        />
      </div>
        );
    }
}

export default Converter;