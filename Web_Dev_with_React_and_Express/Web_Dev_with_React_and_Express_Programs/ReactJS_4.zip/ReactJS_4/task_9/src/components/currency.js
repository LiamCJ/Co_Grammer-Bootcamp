import React from "react";
//make one class component for all converted currencies
class Currency extends React.Component {
  render() {
    const dollars = this.props.dollars;
    return (
      <fieldset>
        <legend>{this.props.value}</legend>
        <input
          value={dollars}
          readOnly
        />
      </fieldset>
    );
  }
}

export default Currency;