import React from "react";
import "./cards.css";

// functional component for the user reward
const Reward = () => {
  var outcome = ["You Win A PC", "You Lose "]; // an array with two outcomes 
  return outcome[Math.floor(Math.random() * outcome.length)]; // the function returns a random index of the array 
};
// class component for the cards
class Cards extends React.Component {
  render() {
    return (
      <div
        id="card"
        onClick={e => {
          this.setState({ component: 1 });
        }}
      >
  {/*This Users award is displayed here*/}
        <Reward />
        <br/>
         The Game Will Now Reset
      </div>
    );
  }
}
// class component that displays all the cards
class Win extends React.Component {
  render() {
    return (
      <article>
        <h1>Welcome To Win!</h1>
        <h3>Please Select A Card</h3>
        <hr />
        <Cards />
        <Cards />
        <Cards />
      </article>
    );
  }
}

export default Win;
