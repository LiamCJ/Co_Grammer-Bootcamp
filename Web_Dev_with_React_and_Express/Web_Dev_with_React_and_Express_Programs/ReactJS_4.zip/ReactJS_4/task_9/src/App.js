import React from "react";
import Converter from "./components/currencyConverter.js";
import Win from "./components/win.js";

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = { component: 0 };
    }
    render() {
      //an array that holds the components that will be displayed when selected in the option
        const components = [<Converter />, <Win />];
        return (
            <section>
          {/*when the option is selected in the drop down, the value of the state (component) is changed according to the value of the 
          option selected*/}
        <select
          onChange={e => {
            this.setState({ component: e.target.value });
          }}
        >
          <option value="0">Converter</option>
          <option value="1">Win!</option>
        </select>
        <hr />
      {/*A component in the the array (components) is displayed depending on what the value of the state (component)
      eg: if the state (component)'s value is 1 the index 1 in the array (components) is displayed*/}
        {components[this.state.component]}
      </section>
        );
    }
}

export default App;