/*As long as the Currency Converter or Win has not been selected on the drop-down, this component will display */
import React from "react";

function Choose() {
  return (
    <div className="App">
      <br/>
        <br/>
      <h1>Please choose an option</h1>
    </div>
  );
}

export default Choose;
