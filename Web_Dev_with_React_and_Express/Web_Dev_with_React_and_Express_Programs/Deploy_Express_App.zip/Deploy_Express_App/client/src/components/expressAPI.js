import React from "react";

class ApiCall extends React.Component {
    state = {
        webProject: [],
        id: "",
        title: "",
        descrip: "",
        url: "",
        key: "title",
        change:""
    }

    // a life cycle that gets the data from the api
    componentDidMount = async () => {
        const data = await fetch("/api");
        const result = await data.json();
        try {
            // the state (webProject) is set to the data fetched from the api
            this.setState({
                webProject: result
            })
        } catch (err) {
            console.log(err)
        }
    }
    // arrow function that adds new data to the api
    post = () => {
        // [lines 29,47,64] store the data that will be sent to the api
        let data = {
            id: this.state.id,
            title: this.state.title,
            description: this.state.descrip,
            URL: this.state.url
        }
        // [lines 35-42,53-59,67-73] uses the fetch method to send the post,put and delete requests, where the body is sent to the api as JSON data
        fetch("/api", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        document.location.reload(); //[lines 42,59,73] refreshes page
    }
    // arrow function that edits data in the api
    put = () => {
        let data = {
            id: this.state.id,
            key: this.state.key,
            change: this.state.change
        }

        fetch("/api", {
            method: "PUT",
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        document.location.reload();        
    }
    // arrow function that deletes data from the api
    remove = () => {
        let data = {
            id: this.state.id
        }
        fetch("/api", {
            method: "DELETE",
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        document.location.reload();
    }

    render() {
        return (
            <React.Fragment>
                    <fieldset>
                        {/* The UI for the post request where the user enter the data they wish to add to the api */}
                        <legend>POST Request</legend>
                        <h3>Enter The New Data BY Filling In The Appropriate Text Boxes Then Click The Button</h3>
                        <label>ID: </label>
                        <input type="text" onChange={(e) => this.setState({ id : e.target.value})} /> <br/>
                        <label>Title: </label>
                        <input type="text" onChange={(e) => this.setState({ title: e.target.value})} /> <br/>
                        <label>Description: </label>
                        <input type="text" onChange={(e) => this.setState({ descrip: e.target.value})} /> <br/>
                        <label>URL: </label>
                        <input type="text" onChange={(e) => this.setState({ url: e.target.value})} /> <br/>
                        <button onClick={() => this.post()}>Post</button>
                    </fieldset>
                    <br />
                    <fieldset>
                        {/* The UI for the put request where the user selects whether they want to change the title or 
                        description then the ID of the object then what they want to change about what they selected */}
                        <legend>PUT Request</legend>
                        <h3>Choose between Title or Description Then Enter The ID and The New Details The Click The Button</h3>
                        <select onChange={(e) => this.setState({key: e.target.value})}>
                            <option value="title">Title</option>
                            <option value="description">Description</option>
                        </select> <br/>
                        <label>ID: </label>
                        <input type="number" onChange={(e) => this.setState({ id : e.target.value})} /> <br/>
                        <label>Change:</label><br/>
                        <textarea rows="15" cols="50" placeholder="Enter The New Details" onChange={(e) => this.setState({ change : e.target.value})} ></textarea> <br/>
                        <button onClick={() => this.put()}>Put</button>
                    </fieldset>
                    <br />
                    <fieldset>
                        {/* The UI for the delete request where the user enter the id of the object they wish to delete */}
                        <legend>DELETE Request</legend>
                        <h3>Enter The ID of The Data You Wish To Delete Then Click The Button</h3>
                        <label>ID: </label>
                        <input type="text" onChange={(e) => this.setState({ id : e.target.value})} /> <br/>
                        <button onClick={() => this.remove()}>Delete</button>
                    </fieldset>
                    <br />
                    <article id="display">
                        {this.state.webProject.map(object =>
                            <article key={object.id} id="object">
                                <h1>ID: {object.id}</h1>
                                <h3>Title: {object.title}</h3>
                                <h3>Description:</h3>
                                <p>{object.description}</p>
                                <h3>URL:</h3>
                                <a href={object.URL}>Games Website</a>
                            </article>
                        )}
                    </article>
            </React.Fragment>
        )
    }
}

export default ApiCall;