import React from 'react';
import ApiCall from './components/expressAPI.js';
import './App.css';

function App() {
  return (
    <section>
      <article>     
          <ApiCall />
      </article>
    </section>
  );
}

export default App;
