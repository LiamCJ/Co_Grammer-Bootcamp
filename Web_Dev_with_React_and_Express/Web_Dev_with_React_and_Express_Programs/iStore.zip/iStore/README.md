How To Use:

Select One Of The Buttons: 
	Apple Music
	Favorites
	Apple Books 
Once Selecting Either Apple Music Or Apple Books
	Click on the bar that says "Enter Your Query" And Select The Format Of Your Search Then Click The Search Button
	Once Your Search Is Displayed You Will Be Able To Add An Item To Your Favorites 

Selecting The Favorites Button You Will Be Able To View The Items You Have Added To Your Favorites 


App Link = https://secret-bayou-25643.herokuapp.com/#/