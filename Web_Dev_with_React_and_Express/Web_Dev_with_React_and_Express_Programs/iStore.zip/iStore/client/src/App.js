import React from 'react';
import './App.css';
import Fav from './components/Favorites'
import Itunes from './components/music'
import BookStore from './components/books'
import home from './components/index'
import symbol from './images/symbol.png'
import { Route, NavLink, HashRouter as Router} from 'react-router-dom'

class App extends React.Component {
    render() {
        return (
            <section>
                    <Router>
                        <NavLink activeClassName="active" to="/"><img id="symbol" src={symbol} alt="symbol"/></NavLink><br/>
                        <article id="nav"><NavLink className="hov" id="navL" activeClassName="active" to="/Apple_Music">Apple Music</NavLink></article>
                        <article id="nav"><NavLink className="hov" id="navL" activeClassName="active" to="/Favorites">Favorites</NavLink></article>
                        <article id="nav"><NavLink className="hov" id="navL" activeClassName="active" to="/Apple_Books">Apple Books</NavLink></article>
                            <Route exact path="/" component={home} />
                            <Route path="/Apple_Music" component={Itunes} />
                            <Route exact path="/Favorites" component={Fav}  />
                            <Route path="/Apple_Books" component={BookStore} />
                    </Router>   
            </section>
        )
    }
}

export default App;