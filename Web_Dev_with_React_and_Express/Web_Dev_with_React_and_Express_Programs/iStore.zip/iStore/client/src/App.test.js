import React from 'react';
import ReactDOM from 'react-dom';
import renderer from 'react-test-renderer';
import {App,getMusic,res} from './App';
import {Itunes,getMusic,res} from "./components/music";

// testing the fetch()
it.todo("getMusic"), done => {
	function callBack(data){
		expect(data).toBe("res");
		done();
	}
	callBack()
    const div = document.createElement('div');
    ReactDOM.render(<Itunes />, div);
    ReactDOM.unmountComponentAtNode(div);
};

// taking a snapshot of the Weather component when it is first displayed
it("Test Was A Success", () => {
	const component = renderer.create(<Itunes/>)
	let app = component.toJSON();
	expect(app).toMatchSnapshot();
})