import React from 'react';
import remove from '../images/remove.png'

class Fav extends React.Component {
	    constructor() {
        super();
        this.state = {
            api:[]
       }
     }
     // a life cycle with an async await to get the api's data
	componentDidMount = async () => {
        const getFavs = await fetch(`/favorites`)
        let res = await getFavs.json()
        this.setState({
            api: res
        })
    }
    // a function that removes items from the users favorites
     remove = (rmvID) => {
        let data = {
            id: rmvID
        }

        fetch("/favorites", {
            method: "DELETE",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        window.location.reload();
    }

render(){
		return (
			<React.Fragment>
				<h1 id="head">Favourites</h1>
				<table>
				<tbody>
					{this.state.api.map( res => 
                        <tr key={res.workId}>
	                        <td><img src={res.img} alt={res.workName}/></td>
	                        <td>{res.workArtist}</td> 
	                        <td>{res.workName}</td> 
	                          {/* the button that calls the function "remove" */}
	                        <td><button onClick={() => this.remove(res.workId)} className="borderRmv shape fav hov"><img id="favImg" src={remove} alt={res.workName}/>Delete</button></td>                  
                        </tr>
                    )
				}
				</tbody>
				</table>
			</React.Fragment>
		)
	}
}

export default Fav