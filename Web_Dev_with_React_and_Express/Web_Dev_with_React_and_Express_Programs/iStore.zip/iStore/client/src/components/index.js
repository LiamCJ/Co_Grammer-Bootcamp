import React from 'react';

const BookStore = () => {
    return (
            <React.Fragment>
                <h1 id="head">Welcome To The iStore</h1>
                <p>You Are Able To Search Any Song,Album,E-Book or Audio Book</p> 
            </React.Fragment>
        )
}

export default BookStore