import React from 'react';
import favIcon from '../images/favourite.png'

class BookStore extends React.Component {
    constructor() {
        super();
        this.state = {
            api:[],
            types: "ebook"
       }
   }

     // an async await function that get the results that the user enters 
    bookS = async () => {
        // the search that the user enters gets splits and joint by "+" to suite the api 
        let search = this.state.bookInput.split(" ").join("+");
        // the apis data fetched from here with the details that the user wants 
        const getbook = await fetch(`/books?search=${search}&type=${this.state.types}`)
        let res = await getbook.json()
        this.setState({
            api: res.results
        })
    }

    // the function that uses a post method to send the users favorite item
    favorite = (id,name,artist,image) => {
        let newFav = {
            workId: id,
            workName: name,
            workArtist: artist,
            img: image
        }

        fetch("/favorites", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newFav)
        })
        alert(`${name} has been added to your favorites`)
    }
  // audiobook
    render(){
        return (
            <React.Fragment>
                <h1 id="head">Apple Books</h1>
                {/* the user enters their search here */}
                <input className="borderRmv shape" type="text" placeholder="Enter Your Query" onChange={(e) => this.setState({bookInput: e.target.value})} />
                {/* the drop down where the user can choose whether they want the results to be ebook or audiobook */}
                <select className="borderRmv shape click hov" onChange={(e) => this.setState({types: e.target.value})}>
                    <option>Select Format Of Search</option>
                    <option value= "ebook" >E-Book</option>
                    <option value= "audiobook" >Audio Book</option>
                </select>
                {/* the search button that calls the "bookS" function */}
                <button id="search" className="borderRmv shape hov" onClick={() => this.bookS()}>Search</button>
                {this.state.types == "ebook" ? 
                    this.state.api.map( res => 
                            <article key={res.trackId}>
                            <h1 id="top">{res.trackName}</h1>
                            {/* the button that call the "favorite" function */}
                            <button className="borderRmv shape fav hov" id="top" onClick={() => this.favorite(res.trackId,res.trackName,res.artistName,res.artworkUrl100)}><img id="favImg" src={favIcon} alt="favorite"/>Add To Favourites</button><br/>
                            <p>Genres: {res.genres.map( genre => genre + " ")}</p>
                            <img id="disp" src={res.artworkUrl100} alt={res.trackName}/>
                            <div id="disp"> 
                                <h3>Artist: {res.artistName}</h3>
                            </div>                       
                            </article>
                    )
                 : 
                     this.state.api.map( res => 
                                <article key={res.trackId}>
                                <h1 id="top">{res.collectionName}</h1>
                                {/* the button that call the "favorite" function */}
                                <button className="borderRmv shape fav hov" id="top" onClick={() => this.favorite(res.trackId,res.collectionName,res.artistName,res.artworkUrl100)}><img id="favImg" src={favIcon} alt="favorite"/>Add To Favourites</button><br/>
                                <p>Genres: {res.primaryGenreName}</p>
                                <img id="disp" src={res.artworkUrl100} alt={res.trackName}/>
                                <div id="disp"> 
                                    <h3>Artist: {res.artistName}</h3>
                                    <audio className="borderRmv" controls><source src={res.previewUrl} type="audio/mpeg"/></audio>
                                </div>                       
                                </article>
                        )
                 }
                                   
            </React.Fragment>
        )
    }
}

export default BookStore