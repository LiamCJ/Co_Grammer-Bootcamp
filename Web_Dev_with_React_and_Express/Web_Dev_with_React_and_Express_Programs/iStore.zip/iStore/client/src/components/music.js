import React from 'react';
import favIcon from '../images/favourite.png'

class Itunes extends React.Component {
    constructor() {
        super();
        this.state = {
            api:[],
            musicInput: "",
            types:"song"
       }
     }
     // an async await function that get the results that the user enters 
	musicS = async () => {
		// the search that the user enters gets splits and joint by "+" to suite the api 
		let search = this.state.musicInput.split(" ").join("+");
		// the apis data fetched from here with the details that the user wants
        const getMusic = await fetch(`/music?search=${search}&type=${this.state.types}`)
        let res = await getMusic.json()
        this.setState({
            api: res.results
        })

        console.log(this.state.api)
    }
    // the function that uses a post method to send the users favorite item
   	favorite = (id,name,artist,image) => {
   		let newFav = {
   			workId: id,
   			workName: name,
   			workArtist: artist,
   			img: image
   		}
  
   		fetch("/favorites", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(newFav)
        })
        alert(`${name} has been added to your favorites`)
   	}

	render(){
		return (
			<React.Fragment>
				<h1 id="head">Apple Music</h1>
				{/* the user enters their search here */}
				<input className="borderRmv shape" type="text" placeholder="Enter Your Query" onChange={(e) => this.setState({musicInput: e.target.value})} />
				{/* the drop down where the user can choose whether they want the results to be songs or ablums */}
				<select className="borderRmv shape click hov" onChange={(e) => this.setState({types: e.target.value})}>
					<option>Select Format Of Search</option>
					<option value= "song" >Songs</option>
					<option value= "album" >Albums</option>
				</select>
				{/* the search button that calls the "musicS" function */}
				<button id="search" className="borderRmv shape hov" onClick={() => this.musicS()}>Search</button>
					{/* a boolean statement that determines what format the results is displays 
					if the state "types" is song the map at [lines 59-72] occurs but if the state "types" is album the map at [line 74-83 ] occurs */}
                    {this.state.types == "song" ? 
                    	this.state.api.map( res => 
	                        <article key={res.trackId}>
		                        <h1 id="top">{res.trackName}</h1>
		                        {/* the button that call the "favorite" function */}
		                        <button className="borderRmv shape fav hov"  id="top" onClick={() => this.favorite(res.trackId,res.trackName,res.artistName,res.artworkUrl100)}><img id="favImg" src={favIcon} alt="favorite"/> Add To Favorites</button><br/>
		                        <img id="disp" src={res.artworkUrl100} alt={res.trackName}/>
		                        <div id="disp"> 
		                            <h3>Artist: {res.artistName}</h3>
		                            <h3>Album: {res.collectionName}</h3>
		                            <h3>Explictness: {res.trackExplicitness}</h3>
		                            <audio className="borderRmv" controls><source src={res.previewUrl} type="audio/mpeg"/></audio>
		                        </div>                      
	                        </article>
                        )
                        : 
                        this.state.api.map( res => 
	                        <article key={res.collectionId}>
		                        <h1 id="top">{res.collectionName}</h1>
		                        {/* the button that call the "favorite" function */}
		                        <button className="borderRmv fav"  id="top" onClick={() => this.favorite(res.collectionId,res.collectionName,res.artistName,res.artworkUrl100)}><img id="favImg" src={favIcon} alt="favorite"/></button><br/>
		                        <h3>Artist: {res.artistName}</h3>
		                        <h3>Explictness: {res.collectionExplicitness}</h3>
		                        <img id="disp" src={res.artworkUrl100} alt={res.collectionName}/>                       
	                        </article>
                        )                       
                    } 
			</React.Fragment>
		)
	}
}

export default Itunes