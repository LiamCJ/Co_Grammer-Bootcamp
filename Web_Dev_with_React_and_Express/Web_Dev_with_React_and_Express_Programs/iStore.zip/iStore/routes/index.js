const bodyParser = require('body-parser');
var favs = require(__dirname + "/favorites.json")
const fetch = require('node-fetch');
const express = require('express');
const router = express.Router();
const helmet = require('helmet');
const fs = require('fs');
const app = express();

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());
app.use(express.json());
app.use(helmet());

// get router for the music
router.get('/music', (req,res) => {
    fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(req.query.search)}&limit=5&entity=${encodeURIComponent(req.query.type)}`)
    .then((res) => {
        return res.json();
    })
    .then((output) =>{
        res.send(JSON.stringify(output));
    })
})
// get router for the music
router.get('/books', (req,res) => {
    fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(req.query.search)}&limit=5&entity=${encodeURIComponent(req.query.type)}`)
    .then((res) => {
        return res.json();
    })
    .then((output) =>{
        res.send(JSON.stringify(output));
    })
})
// get router for the favorites
router.get('/favorites',(req,res) => {
    res.json(favs)
})

// post router for the favorites
router.post('/favorites',(req,res) => {
     favs.push(req.body);
     //writing the changes made to the array
     fs.writeFile(__dirname + "/favorites.json", JSON.stringify(favs), (err) => {
        if (err) {
            console.log("File Not Updated")
        }else {
            res.json(favs)
        }
     })
})


router.delete('/favorites',(req, res) => {
//  the array is filtered in a way that all objects that do not have the id the user entered 
//  will be returned to the array with the object with the id the user entered being left out 
    favs = favs.filter((obj) => {
        return obj.workId != req.body.id;
    })  
    // writing the array to the JSON file "webProject"
     fs.writeFile(__dirname + "/favorites.json", JSON.stringify(favs), (err) => {
        if (err) {
            console.log("File Not Updated")
        }else {
            res.json(favs)
        }
     })
})

module.exports = router;
