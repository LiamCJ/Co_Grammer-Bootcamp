const assert = require("chai").assert;
const index = require("../routes/index.js")

//testing the function
describe("Music Output" , () => {
	it("Checking for functionality", () => {
		assert.equal(index(450000),262263)
	})
})