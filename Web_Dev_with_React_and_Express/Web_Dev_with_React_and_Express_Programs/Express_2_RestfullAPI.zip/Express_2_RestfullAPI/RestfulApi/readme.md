How To Use The:

Get Request:
When Using Get To Display Json Data The Path http://localhost:8080/api Should Be Used
e.g: 

Post Request:
When Using Post To Add New Data To The Json The Path Should Be Used The Following Way:
http://localhost:8080/api?id=(Your Custom Id)&title=(The Title Of The Data)&description=(A Description Of The Data)&URL=(The Url That Can Be Used To Display The Data)
e.g:

Delete Request:
When Using Delete To Remove Data From The Json The Path Should Be Used In The Following Way:
http://localhost:8080/api?remove=(Specify The Id Of The Data You Want To Remove)
e.g:

Put Request:
When Using Put To Updating Data From The JSON
e.g: