import React from 'react';
import './App.css';
import Header from './components/header.js'; //Importing the Header component
import Landing from './components/landing.js'; //Importing the Landing  component
import Product from './components/product.js'; //Importing the Product  component

//The JSX that displays all the components created in there respective files
const Ubisoft = () => {
    return (
    <section>
        <Header />
        <Landing />
        <Product />
    </section>
    );
}

//exporting the JSX that will be imported by the index.js
export default Ubisoft;