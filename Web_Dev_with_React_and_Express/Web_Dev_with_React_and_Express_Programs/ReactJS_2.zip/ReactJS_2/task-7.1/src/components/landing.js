import React from 'react';

//a component that holds the information about the company in an article with the ID (info)
class Landing extends React.Component {
    render() { //converts the JSX into a format readable for the HTML webpage
        return (
    <article id="info">
            Ubisoft Entertainment SA Is A French Video Game Company Founded In 28 March 1986 <br />
            Headquartered In Montreuil With Several Development Studios Across The World. <br />
            It Publishes Games For Several Video Game Franchises, Including Assassin's Creed, Watch Dogs, And Tom Clancy's. <br />
            As of March 2018, Ubisoft is the fourth largest publicly traded game company in the Americas and Europe in terms of revenue and market capitalisation
    </article>
        )
    }
}

// exporting the component called Landing that is imported by the App.js
export default Landing;