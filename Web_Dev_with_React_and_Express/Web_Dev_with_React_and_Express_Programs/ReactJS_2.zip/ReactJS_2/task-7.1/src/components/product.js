import React from 'react';
import Ac from '../images/AC_Odyssey.jpg';
import Gr from '../images/GR_Breakpoint.jpg';
import Wd from '../images/WD_Legion.jpg';

// functional component that returns the products form the array (productObj) along with there unique keys
const ProductMapping = (props) => {
    const products = props.products; // getting the array of objects

    const productMap = products.map((product) =>
        // each product is displayed in a article with the image and title
        <article id={product.id} key={product.id.toString()}>
            <img src={product.image} alt={product.Title} />
            <h1>{product.Title}</h1>
        </article>
    );
    return (
        // the products are returned in this section
        <section>{productMap}</section>
    );
}

//a component that will displays the products in an article with the ID (products)
class Product extends React.Component {
    render() { //converts the JSX into a format readable for the HTML webpage
        // array of objects with the products ids, images & titles
        const productObj = [{id: "ac",image: Ac, Title: "Assassins Creed: Odyssey R450"},
                            {id: "gr",image: Gr, Title: "Ghost Recon: Breackpoint R500"},
                            {id: "wd",image: Wd, Title: "Watch Dogs: Legion R500"}]
        return (
    <article id="products">
        <ProductMapping  products={productObj}/>
    </article>
        )
    }
}
// exporting the component called Product that is imported by the App.js
export default Product

/*
Ac : Assassins Creed

Gr : Ghost Recon

Wd : Watch Dogs
*/