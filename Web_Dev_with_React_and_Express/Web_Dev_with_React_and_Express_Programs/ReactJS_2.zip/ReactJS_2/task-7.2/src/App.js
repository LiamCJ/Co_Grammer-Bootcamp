import React from 'react';
import './App.css';
import Bio from './components/bio.js'; //imports the component Bio
import Info from './components/info.js'; //imports the component Info

//here all the components are put together to be displayed
const Cv = () => {
    return (
    <section>
        <Bio />
        <article id="exp">
            <Info field="Experience:" infoOne="1 Month of python" infoTwo="2 Months of HTML & CSS" infoThree="2 Month of JavaScript" />
        </article>
        <article id="edu">
            <Info field="Eduction:" infoOne="Matriculated in 2018 with a Diploma Pass" infoTwo="At Heathfield High School" infoThree="CoGrammer Bootcamp" />
        </article>
        <article id="skl">
            <Info field="Skills:" infoOne="Python" infoTwo="HTML & CSS" infoThree="JavaScript" />
        </article>
    </section>
    )
}

//exporting the JSX that will be imported by the index.js
export default Cv;