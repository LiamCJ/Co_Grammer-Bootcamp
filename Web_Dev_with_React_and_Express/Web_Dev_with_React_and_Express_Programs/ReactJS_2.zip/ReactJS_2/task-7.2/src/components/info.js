import React from 'react';

//the component that acts a compiler for the information of the users education,experience,and skills
class Info extends React.Component {
    render() { //converts the JSX into a format readable for the HTML webpage
        return (
    <div>
        <h1> {this.props.field}</h1> {/*here a the name of the field is displayed eg:Experience,Education or Skills*/}
        <div>
            <h3>{this.props.infoOne}</h3> {/*Displays the 1st entry of the field*/} 
            <h3>{this.props.infoTwo}</h3> {/*Displays the 2nd entry of the field*/} 
            <h3>{this.props.infoThree}</h3> {/*Displays the 3rd entry of the field*/} 
        </div>
    </div>
        )
    }
}

// exporting the component called Info that is imported by the App.js
export default Info;