import React from 'react';
import Profile from '../images/image.jpg'; //imports the profile picture as Profile

//The component that displays the profile pic,full name,ID,Email,phone number,and address in an article
class Bio extends React.Component {
    render() { //converts the JSX into a format readable for the HTML webpage
        return (
    <article id="bio">
        <div id="profilePic">
            <img src={Profile} alt="Profile_Picture" />
        </div>
        <div id="info">
            <h1>Liam Jones</h1>
            Email: liamcjones2000@gmail.com <br />
            Phone Number: 065 717 7367 <br />
        </div>
        <div id="address">
            Address: 8 Hercules <br />
            <p className="tab">Lotus River <br />
                Cape Town <br />
                7941 <br />
                South Africa
            </p>
        </div>
    </article>
        )
    }
}
// exporting the component called Bio that is imported by the App.js
export default Bio;