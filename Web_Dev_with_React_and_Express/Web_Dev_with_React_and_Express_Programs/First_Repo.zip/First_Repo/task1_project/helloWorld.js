console.log("Git is Awesome"); //displaying a text in the console

function ent() {
    var inp = document.getElementById("input");
    document.getElementById("output").innerHTML = inp.value; //displaying the input from the user
}
