import React from "react";
import "./App.css";

class App extends React.Component {
    //a constructor that initializes the result to a blank text
    constructor(props) {
    super(props);
    this.state = { result: "" };
    }
    //a function component that concatenates the button's content clicked to the result
    add = value => {
    this.setState({ result: this.state.result + value });
    };

    //a function component that calculates the equation inside result with eval()
    cal = () => {
    this.setState({ result: eval(this.state.result) });
    };

    //a function component that clears of all text  by setting the state of result back to blank
    clr = () => {
    this.setState({ result: "" });
    };
   /*the component returns a table that displays the calculators input and buttons with 4 buttons in each row and
   when the button the AC button is clicked it calls the (clr - line 21) function which sets the state (result) to blank
   when the equal button is clicked it calls the (cal - line 16) function
   if any other button is clicked it will call the function (add - line add) */ 
    render() {
        return (
            <table>
                <tbody>
                    <tr>
                      <td colSpan="4">
                        <input type="text" value={this.state.result} />
                      </td>
                    </tr>
                    <tr>
                        <td>
                            <button onClick={() => this.add("(")}>(</button>
                        </td>
                        <td>
                            <button onClick={() => this.add(")")}>)</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("%")}>%</button>
                        </td>
                        <td>
                            <button onClick={this.clr}>AC</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button onClick={() => this.add("7")}>7</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("8")}>8</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("9")}>9</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("+")}>+</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button onClick={() => this.add("4")}>4</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("5")}>5</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("6")}>6</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("-")}>-</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button onClick={() => this.add("1")}>1</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("2")}>2</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("3")}>3</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("*")}>x</button>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <button onClick={() => this.add(".")}>.</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("0")}>0</button>
                        </td>
                        <td>
                            <button onClick={this.cal}>=</button>
                        </td>
                        <td>
                            <button onClick={() => this.add("/")}>/</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        );
    }
}

export default App;
