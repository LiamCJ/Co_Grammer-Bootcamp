import React from "react";
import Tasks from "./Tasks.js";

class Todo extends React.Component {
    constructor(props) {
        super(props);
        this.state = { tasks: [] };
    }
    
    //a function that adds tasks to the ToDo list with a key of the the task is created
    addTask = input => {
        var newTask = {
            text: this.userInput.value,
            key: new Date().toLocaleTimeString()
        };
        //concatenates the input into the tasks array in order for i to be displayed
        this.setState(prev_state => {
            return {
                tasks: prev_state.tasks.concat(newTask)
            };
        });
        //resets the input tag to blank
        this.userInput.value = "";
        //prevents the page from reloading
        input.preventDefault();
    };

    //deletes a task from the tasks array
    deleteTask = key => {
        var removeTask = this.state.tasks.filter(task => {
            return task.key !== key;
        });
        this.setState({
            tasks: removeTask
        });
    };

    render() {
        return (
            <div>
        <div>
          <form onSubmit={this.addTask}>
            <input
              ref={a => (this.userInput = a)}
              placeholder="Enter Task"
            />
            <button type="submit">Add</button>
          </form>
        </div>
        <Tasks entries={this.state.tasks} delete={this.deleteTask} />
      </div>
        );
    }
}

export default Todo;