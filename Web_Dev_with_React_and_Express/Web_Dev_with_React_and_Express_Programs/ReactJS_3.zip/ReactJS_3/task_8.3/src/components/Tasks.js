import React from "react";

class Tasks extends React.Component {
    //function item that creates a constructor for the tasks of the todo list which displays the task inputted by the user along with the time it was created
    displayTask = task => {
        return (
            <li onClick={() => this.props.delete(task.key)} key={task.key}>
        {task.text} <br/> Time Created:{task.key}
      </li>
        );
    };

    render() {
        //holds the data of the state (tasks)
        var newTasks = this.props.entries;
        //creates a map of the tasks in order to be displayed one by one as list items in an ordered list
        var taskList = newTasks.map(this.displayTask);

        return <ul>{taskList}</ul>;
    }
}

export default Tasks;