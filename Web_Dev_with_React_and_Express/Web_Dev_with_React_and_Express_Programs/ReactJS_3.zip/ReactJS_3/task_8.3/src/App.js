import React from 'react';
import './App.css';
import Todo from './components/TodoList';

//the class component that displays the todo list
class App extends React.Component {
    render() {
        return (
            <div>
     			<Todo/>
    		</div>
        );
    }
}

export default App;