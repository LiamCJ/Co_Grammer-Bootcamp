import React from "react";
import Logo from "../images/ubiLogo.png"; //importing an image

class LoginControl extends React.Component {
  // a constructor that has a property (loggedIn) and initializes the state as false
  constructor(props) {
    super(props);
    this.state = { loggedIn: false, userName: "" };
  }
  // A function that sets the state of loggedIn to true
  logIn = () => {
    this.setState({ loggedIn: false });
  };
  // A function that sets the state of loggedIn to false
  logOut = () => {
    this.setState({ loggedIn: true });
  };

  render = () => { //converts the JSX into a format readable for the HTML web page
    const loggedIn = this.state.loggedIn;
    return (
      <div>
        {loggedIn ? (
          // if loggedIn is true the below JSX will be returned with the (logIn) function being applied to the onClick event
          <article>
            <label>WELCOME BACK: {this.state.userName} </label>
            <button type="submit" onClick={this.logIn}>Log Out</button>
          </article>
        ) : (
          // if loggedIn is false the below JSX will be returned with the (logOut) function being applied to the onClick event
          <article>
            <label>PLEASE SIGN IN </label>
          {/*the data entered by the user will be capitalized and will set the state (userName) to the users input*/}
            <input onChange={(e) => this.setState({ userName: e.target.value.toUpperCase()})} type="text" placeholder="Enter Your Full Name" />
            <button onClick={this.logOut}>Log In</button>
          </article>
        )}
      </div>
    );
  }
}

//The component that will display the company's logo,name and a logIn and logOut option
class Header extends React.Component {
    render() { //converts the JSX into a format readable for the HTML webpage
        return (
            <article>
                <div id="brnd">
                    <img id="logo" src={Logo} alt="Ubisoft_Logo" />
                    <h1 id="title">Ubisoft</h1>
                </div>
                <div id="wel">
                    <LoginControl />
                </div>
            </article>
        );
    }
}
// exporting the component called LoginControl that is imported by the App.js
export default Header;