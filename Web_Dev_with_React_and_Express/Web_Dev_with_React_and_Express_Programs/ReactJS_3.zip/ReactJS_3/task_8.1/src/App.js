import React from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Header from "./components/header.js";
import Landing from "./components/landing.js";
import Product from "./components/product.js";

//the class component that displays the components when they are selected in the navbar except for the header which is always displayed
class App extends React.Component {
  render() {
    return (
    <section>
            <Header/>
            <Router>
                <div>
                    <ul>
                {/*displaying the navigation links and what is displayed when on a page  */}
                        <Route path={["/product"]} render={() => <Link id="li" to="/">Home</Link>} />
                        <Route exact={true} path={["/"]} render={() => <Link id="li" to="/product">Product</Link>} />
                    </ul> 
                {/*Where the components will be displayed*/}
                        <Route exact={true} path={"/"} component={Landing} />
                        <Route path={"/product"} component={Product} />
                </div>
            </Router>
    </section>
    );
  }
}

export default App;
