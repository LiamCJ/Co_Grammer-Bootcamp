# Task_10

Rules and Guidelines of how to play Rock, Paper, Scissors:

1. In order to begin the game you should click the "BEGIN!" button 
2. You must select a hand symbol that is displayed below the "Player 1" sign
3. A player who decides to play rock will beat another player who has chosen scissors but will lose to one who has played paper a play of paper will lose to a play of scissors.
