import React from "react";
import "../App.css";
import Rock from "../images/rock.png";
import Paper from "../images/paper.png";
import Scissors from "../images/scissors.png";

// a class component that returns the users outcome of the game
class Player extends React.Component {
  render() {
    const playerHand = this.props.pl1;
    return (
      <article>
        <div id="plyr" className="stage">
          <h1>Player 1</h1>
          <h3>CHOOSE YOUR WEAPON</h3>
          {/*if either of the images in lines [75-77] are clicked they will set the state of (pl1) to there relative symbols*/}
          <img
            id="userHand"
            onClick={() => this.props.userHand("rock")}
            src={Rock}
            alt="Rock"
          />
          <img
            id="userHand"
            onClick={() => this.props.userHand("paper")}
            src={Paper}
            alt="Paper"
          />
          <img
            id="userHand"
            onClick={() => this.props.userHand("scissors")}
            src={Scissors}
            alt="Scissors"
          />
          <br />
          {/*[lines 80 & 84] both display images depending on what there relative states are*/}
          <img src={"./images/" + playerHand + ".png"} alt="playerHand" />
        </div>
      </article>
    );
  }
}

export default Player;
