import React from "react";

// a class component that returns the header of the game
class Header extends React.Component {
  render() {
    return (
      <article>
        {/*Displaying if the user won,tied or lost*/}
        <h1 id="headings">{this.props.winner}</h1>
        {/*the button that begins the game*/}
        <button onClick={this.props.beginGame}>BEGIN!</button>
      </article>
    );
  }
}

export default Header;
