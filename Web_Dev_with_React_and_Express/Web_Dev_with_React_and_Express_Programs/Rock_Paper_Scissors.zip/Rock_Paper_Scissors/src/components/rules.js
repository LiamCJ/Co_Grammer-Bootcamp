import React from "react";

// a class component that returns a button that returns the rules of the game
class Rules extends React.Component {
  render() {
    return (
      <article>
        <h1>How To Play:</h1>
        <ul>
          <li>
            You must select a hand symbol that is displayed below the "Player 1" sign
          </li>
          <li>
            In order to begin the game you should click the "BEGIN!" button
          </li>
          <li>
            A player who decides to play rock will beat another player who has
            chosen scissors but will lose to one who has played paper a play of
            paper will lose to a play of scissors.
          </li>
        </ul>
      </article>
    );
  }
}

export default Rules;
