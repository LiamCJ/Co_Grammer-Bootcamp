import React from "react";
import "../App.css";

// a class component that returns the computers outcome of the game
class Computer extends React.Component {
  render() {
    const comHand = this.props.cpu;
    return (
      <article>
        <div id="cpu" className="stage">
          <h1>CPU</h1>
          <img id="comhnd" src={"./images/" + comHand + ".png"} alt="comHand" />
        </div>
      </article>
    );
  }
}

export default Computer;
