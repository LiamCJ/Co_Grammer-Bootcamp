import React from "react";
import "./App.css";
import Header from "./components/header.js";
import Player from "./components/player.js";
import Computer from "./components/cpu.js";
import Rules from "./components/rules.js";

// displaying the component (outcome)
class App extends React.Component {
    constructor(props) {
        super(props);
        this.hand = ["rock", "paper", "scissors"]; // initializing the array of hand outcomes
        this.state = {
            pl1: "logic", // initializing the player ones hand display
            cpu: "logic", // initializing the computers hand display
            winner: "", // initializing the winner state
            chosen: false // initializing that keeps record of whether the player has selected a hand or not
        };
    }

    // the function that decides who is the winner
    whoWins = () => {
        const playerHand = this.state.pl1;
        const comHand = this.state.cpu;

        // if the players hand is equal to the computers hand it will be a tie 
        if (playerHand === comHand) {
            return "IT IS A TIE!";

        } else if ( // if the the following conditions occur the player wins 
            (playerHand === "rock" && comHand === "scissors") ||
            (playerHand === "paper" && comHand === "rock") ||
            (playerHand === "scissors" && comHand === "paper")
        ) {
            return "YOU WIN!";
        } else { // if any other outcome occurs the player losers
            return "YOU LOSE!";
        }
    };

    // sets what hand sign the user chose
    userHand = sign => {
        this.setState({ chosen: true })
        this.setState({ winner: this.whoWins() });
        return this.setState({ pl1: sign });
    };

    // function that starts the game
    beginGame = () => {

        this.setState({ winner: "" }); //resetting  the state of the winner       
        this.setState({ chosen: false }); //resetting the state of chosen

        let counter = 0;

        // a setInterval for the computer to randomize its chosen hand
        let gameTime = setInterval(() => {
            counter++; // incrementing the counter

            this.setState({
                cpu: this.hand[Math.floor(Math.random() * 3)] // setting the state of the computers chosen hand to a random outcome from the array (hand)
            });

            // when the counter reaches 41 the setInterval will stop and the state (winner) will be set to what is returned from the outcome of (whoWins)
            if (counter > 40 || this.state.chosen === true) {
                clearInterval(gameTime);
                this.setState({ winner: this.whoWins() });
            }
        }, 100);
    };

    render() {
        // array of objects with the id's and components
const components = [
            {id: "rules" ,comp : <Rules />},
            {id: "header" ,comp : <Header winner={this.state.winner} beginGame={this.beginGame} />},
            {id: "player" ,comp : <Player pl1={this.state.pl1} userHand={this.userHand} />},
            {id: "computer" ,comp : <Computer cpu={this.state.cpu}/>}
        ];
        return(  
                    <section>
                                {/* the map that displays the components with the key being the id */}
                                {components.map(
                                    (component) => <article key ={component.id.toString()}>{component.comp}</article>
                                )}
                    </section>
        )
    }
}

export default App;
