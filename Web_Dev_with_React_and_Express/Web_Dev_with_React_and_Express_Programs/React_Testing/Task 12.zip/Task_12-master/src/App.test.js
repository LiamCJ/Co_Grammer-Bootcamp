import React from 'react';
import ReactDOM from 'react-dom';
import renderer from 'react-test-renderer';
import {App,cities,result} from './App';
import Weather from "./components/weather";

// testing the fetch()
it.todo("cities"), done => {
	function callBack(data){
		expect(data).toBe("result");
		done();
	}
	callBack()
    const div = document.createElement('div');
    ReactDOM.render(<App />, div);
    ReactDOM.unmountComponentAtNode(div);
};

// taking a snapshot of the Weather component when it is first displayed
it("Test Was A Success", () => {
	const component = renderer.create(<Weather/>)
	let app = component.toJSON();
	expect(app).toMatchSnapshot();
})