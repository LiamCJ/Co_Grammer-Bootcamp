import React from 'react';

class Weather extends React.Component {
    constructor(props) {
        super(props)
        // initializing the states of all the weather information that will be displayed
        this.state = {
        	country: "",
            cond: "",
            desc:"",
            city: "",         
			temp_current : 0,
			temp_min : 0,
			temp_max : 0,
			pressure : 0,
			humidity : 0,
			wind_speed : 0,
			wind_deg : 0
        }
    };

   	// an async function in order to get the data from the api
    componentDidMount = async () => {
    	// getting the api key from the .env file
    	const id = process.env.REACT_APP_API_KEY
    	// fetching the users request 
        const cities = await fetch("http://api.openweathermap.org/data/2.5/weather?q=" + this.state.city + id);
        // converting the users request is converted to json which is referred to as (result)
        const result = await cities.json();
        try {
        	// setting the states of the weather information when the (result) is loaded
			this.setState({ 
				country: result.sys.country,
				cond: result.weather[0].main,
				desc: result.weather[0].description,         
				temp_current : (result.main.temp - 273.15).toFixed(2),
				temp_min : (result.main.temp_min - 273.15).toFixed(2),
				temp_max : (result.main.temp_max - 273.15).toFixed(2),
				pressure : result.main.pressure ,
				humidity : result.main.humidity ,
				wind_speed : (result.wind.speed * 3.6).toFixed(2) ,
				wind_deg : result.wind.deg
			});
        }
        // if the (result) is not loaded the following will occur
        catch (err) {
            console.log(err); // the error will be displayed in the console
            document.getElementById("city").innerHTML = "That City Does Not Exist"; // the user will be told that the the city they entered will not be entered
			// the states of the weather information will be  reset to there initial states
			this.setState({ 
        		country: "",
				cond: "",
				desc: "",         
				temp_current : 0,
				temp_min : 0,
				temp_max : 0,
				pressure : 0,
				humidity : 0,
				wind_speed : 0,
				wind_deg : 0
			});
        }

    }

     
    render() {
        return (
            <article>
				<input onChange = {(e) => this.setState({ city: e.target.value})} id="inp" className="brder" type="text" placeholder="Enter The Name Of A City" />
				<button className="brder" onClick = {this.componentDidMount} type="submit">Enter</button>
				<h1 id="city">{this.state.city + "," + this.state.country}</h1>
				<h3> Condition: {this.state.cond} <br/> Description: {this.state.desc} </h3>
				<h2>TEMPERATURE</h2>
				    <h3>Current Temperature: {this.state.temp_current}°C </h3> 
					<h3>Minimum Temperature: {this.state.temp_min}°C </h3> 
					<h3>Maximum Temperature: {this.state.temp_max}°C </h3> 
				<h2>PRESSURE</h2>
					<h3>Pressure: {this.state.pressure} pascals </h3> 
				<h2>HUMIDITY</h2>
					<h3>Humidity: {this.state.humidity}% </h3> 
				<h2>WIND</h2>
					<h3>Wind Speed: {this.state.wind_speed}km/h </h3> 
					<h3>Wind Degrees: {this.state.wind_deg}° </h3> 
			</article>
        )
    }
}

export default Weather