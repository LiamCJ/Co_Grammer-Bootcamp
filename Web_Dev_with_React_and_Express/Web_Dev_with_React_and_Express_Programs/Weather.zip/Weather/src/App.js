import React from 'react';
import './App.css';
import Weather from "./components/weather";

function App() {
  return (
    <section>
    <h1 id="head">WHUT? THEE WEATHER</h1>
    <Weather/>
    </section>
  );
}

export default App;
