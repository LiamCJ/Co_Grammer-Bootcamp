To run this code:
1. Copy this example file to your local computer
2. Decompress it
3. Type 'npm install' from the command line
4. Type 'npm test' to run the test