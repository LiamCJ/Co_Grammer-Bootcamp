const BMICalculator = require('../myFunction.js');

const chai = require('chai');
const expect = chai.expect;

describe('#calculate(weight, height)', function() {
    it('should correctly correctly calculate BMI', function() {
        let weight = 75;
        let height = 1.76;
        let expected = '24.21';
        let actual = BMICalculator.calculate(weight,height);
        expect(actual).to.equal(expected);
    });
});
